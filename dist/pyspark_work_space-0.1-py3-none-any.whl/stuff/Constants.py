
values_to_check = ["A", "B"]